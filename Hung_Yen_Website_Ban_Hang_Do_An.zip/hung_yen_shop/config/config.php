<?php
session_start();

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'hung_yen_shop');
define('DB_USER', 'root');
define('DB_PASS', '');

define('SITE_NAME', 'Hưng Yến');
define('SITE_URL', 'http://localhost/hung_yen_shop');

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
    }
    return $pdo;
}

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money($value): string {
    return number_format((float)$value, 0, ',', '.') . '₫';
}

function cart_count(): int {
    return array_sum($_SESSION['cart'] ?? []);
}

function is_admin(): bool {
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}
?>
