# HƯNG YẾN FASHION — ĐỒ ÁN WEBSITE BÁN HÀNG QUẦN ÁO

## 1. Công nghệ
- PHP 8+
- MySQL 8+
- HTML5 / CSS3 / JavaScript
- PDO + Prepared Statements
- Responsive design

## 2. Chức năng
### Khách hàng
- Trang chủ phong cách trẻ trung.
- Xem sản phẩm theo danh mục.
- Tìm kiếm sản phẩm.
- Sắp xếp theo giá.
- Xem chi tiết sản phẩm.
- Thêm / cập nhật / xóa giỏ hàng.
- Checkout và tạo đơn hàng.
- Trừ tồn kho sau khi đặt hàng.

### Quản trị
- Đăng nhập admin.
- Dashboard thống kê sản phẩm, đơn hàng, doanh thu, khách hàng.
- CRUD sản phẩm: thêm, sửa, xóa.
- Cập nhật trạng thái đơn hàng.

## 3. Cài đặt bằng XAMPP
1. Cài XAMPP, bật Apache và MySQL.
2. Copy thư mục `hung_yen_shop` vào `C:\xampp\htdocs\`.
3. Mở phpMyAdmin.
4. Import file `database/hung_yen_shop.sql`.
5. Kiểm tra `config/config.php`: host/user/password MySQL.
6. Truy cập: http://localhost/hung_yen_shop/

## 4. Tài khoản quản trị demo
- Username: admin
- Password: admin123

## 5. Lưu ý
Phần hình ảnh sản phẩm đang dùng giao diện minh họa bằng CSS để dự án chạy ngay không phụ thuộc ảnh ngoài. Khi triển khai thực tế có thể thay `.product-image` bằng ảnh thật trong `assets/images/`.

## 6. Cấu trúc
- `index.php`: Trang chủ
- `products.php`: Danh sách sản phẩm
- `product.php`: Chi tiết
- `cart.php`: Giỏ hàng
- `checkout.php`: Thanh toán
- `success.php`: Xác nhận đơn
- `admin/`: Quản trị
- `database/`: CSDL
- `assets/`: CSS/JS/hình ảnh
- `includes/`: header/footer
- `config/`: cấu hình CSDL
