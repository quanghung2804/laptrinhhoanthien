<?php
require_once 'config/config.php';
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $id = (int)$_POST['product_id']; $qty = max(1, (int)$_POST['qty']);
        $st=$pdo->prepare("SELECT stock FROM products WHERE id=?"); $st->execute([$id]); $stock=(int)$st->fetchColumn();
        if ($stock > 0) $_SESSION['cart'][$id] = min($stock, ($_SESSION['cart'][$id] ?? 0) + $qty);
    } elseif ($action === 'update') {
        foreach ($_POST['qty'] ?? [] as $id=>$qty) {
            $id=(int)$id; $qty=max(0,(int)$qty);
            if ($qty===0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id]=$qty;
        }
    } elseif ($action === 'remove') unset($_SESSION['cart'][(int)$_POST['product_id']]);
    header('Location: cart.php'); exit;
}
$cart=$_SESSION['cart']??[]; $items=[]; $total=0;
if ($cart) {
    $ids=array_keys($cart); $marks=implode(',',array_fill(0,count($ids),'?'));
    $st=$pdo->prepare("SELECT * FROM products WHERE id IN ($marks)"); $st->execute($ids);
    foreach($st as $p){$p['qty']=$cart[$p['id']];$p['subtotal']=$p['qty']*$p['price'];$total+=$p['subtotal'];$items[]=$p;}
}
$page_title='Giỏ hàng'; require 'includes/header.php';
?>
<section class="page-banner"><div class="container"><p class="eyebrow">YOUR BAG</p><h1>Giỏ hàng</h1></div></section>
<section class="container section">
<?php if(!$items): ?><div class="empty"><h2>Giỏ hàng đang trống</h2><p>Chọn một vài item thật hợp vibe nhé.</p><a class="btn btn-dark" href="products.php">Tiếp tục mua sắm</a></div>
<?php else: ?>
<form method="post"><input type="hidden" name="action" value="update">
<div class="cart-list">
<?php foreach($items as $p): ?><div class="cart-item"><div class="cart-thumb product-image tone-<?= $p['id']%6 ?>">HY</div><div class="cart-name"><h3><?=e($p['name'])?></h3><p><?=money($p['price'])?></p></div><input class="qty" type="number" name="qty[<?=$p['id']?>]" min="0" max="<?=$p['stock']?>" value="<?=$p['qty']?>"><strong><?=money($p['subtotal'])?></strong><button class="remove" formaction="cart.php" formmethod="post" name="product_id" value="<?=$p['id']?>">×</button></div><?php endforeach; ?>
</div><div class="cart-actions"><button class="btn btn-outline">Cập nhật giỏ</button><div class="cart-total"><span>Tổng cộng</span><strong><?=money($total)?></strong><a class="btn btn-dark" href="checkout.php">Thanh toán →</a></div></div>
</form>
<?php endif; ?>
</section>
<?php require 'includes/footer.php'; ?>
