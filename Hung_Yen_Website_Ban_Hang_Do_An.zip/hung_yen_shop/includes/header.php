<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title ?? SITE_NAME) ?> | Hưng Yến</title>
    <meta name="description" content="Hưng Yến - thời trang trẻ trung, năng động dành cho giới trẻ.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="header">
    <div class="container nav">
        <a class="logo" href="index.php">HƯNG <span>YẾN</span></a>
        <nav class="menu">
            <a href="index.php">Trang chủ</a>
            <a href="products.php">Sản phẩm</a>
            <a href="products.php?category=1">Áo</a>
            <a href="products.php?category=2">Quần</a>
            <a href="products.php?category=3">Váy</a>
            <a href="products.php?category=4">Phụ kiện</a>
        </nav>
        <div class="nav-actions">
            <a href="products.php" aria-label="Tìm kiếm">⌕</a>
            <a href="cart.php" class="cart-link">🛒 <span><?= cart_count() ?></span></a>
            <a class="admin-link" href="admin/index.php">Quản trị</a>
        </div>
    </div>
</header>
<main>
