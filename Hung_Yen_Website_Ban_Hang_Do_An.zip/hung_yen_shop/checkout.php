<?php
require_once 'config/config.php';
$pdo=db(); $cart=$_SESSION['cart']??[];
if(!$cart){header('Location: cart.php');exit;}
$ids=array_keys($cart);$marks=implode(',',array_fill(0,count($ids),'?'));$st=$pdo->prepare("SELECT * FROM products WHERE id IN ($marks)");$st->execute($ids);
$items=[];$total=0;foreach($st as $p){$p['qty']=$cart[$p['id']];$p['subtotal']=$p['qty']*$p['price'];$total+=$p['subtotal'];$items[]=$p;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim($_POST['name']??'');$phone=trim($_POST['phone']??'');$address=trim($_POST['address']??'');$note=trim($_POST['note']??'');
    if($name===''||$phone===''||$address==='') $error='Vui lòng điền đầy đủ họ tên, số điện thoại và địa chỉ.';
    else {
        try{
            $pdo->beginTransaction();
            foreach($items as $p){if($p['qty']>$p['stock'])throw new Exception('Sản phẩm '.$p['name'].' không đủ tồn kho.');}
            $st=$pdo->prepare("INSERT INTO orders(customer_name,phone,address,note,total,status,created_at) VALUES(?,?,?,?,?,'Mới',NOW())");$st->execute([$name,$phone,$address,$note,$total]);$oid=$pdo->lastInsertId();
            $st=$pdo->prepare("INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)");
            $upd=$pdo->prepare("UPDATE products SET stock=stock-? WHERE id=?");
            foreach($items as $p){$st->execute([$oid,$p['id'],$p['qty'],$p['price']]);$upd->execute([$p['qty'],$p['id']]);}
            $pdo->commit();$_SESSION['cart']=[];header('Location: success.php?order='.$oid);exit;
        }catch(Exception $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
    }
}
$page_title='Thanh toán';require 'includes/header.php';
?>
<section class="container section checkout-grid">
<div><p class="eyebrow">CHECKOUT</p><h1>Thông tin nhận hàng</h1><?php if($error):?><div class="alert"><?=$error?></div><?php endif;?>
<form method="post" class="checkout-form"><input name="name" placeholder="Họ và tên *" required><input name="phone" placeholder="Số điện thoại *" required><textarea name="address" placeholder="Địa chỉ nhận hàng *" required></textarea><textarea name="note" placeholder="Ghi chú (không bắt buộc)"></textarea><button class="btn btn-dark">Đặt hàng</button></form></div>
<aside class="order-box"><h3>Đơn hàng</h3><?php foreach($items as $p):?><div class="order-line"><span><?=$p['qty']?> × <?=e($p['name'])?></span><strong><?=money($p['subtotal'])?></strong></div><?php endforeach;?><hr><div class="order-line"><strong>Tổng</strong><strong><?=money($total)?></strong></div><p class="muted">Thanh toán khi nhận hàng (COD).</p></aside>
</section>
<?php require 'includes/footer.php'; ?>
