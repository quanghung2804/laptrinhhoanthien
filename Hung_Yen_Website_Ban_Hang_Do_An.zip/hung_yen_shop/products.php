<?php
require_once 'config/config.php';
$page_title = 'Sản phẩm';
$pdo = db();
$category = (int)($_GET['category'] ?? 0);
$q = trim($_GET['q'] ?? '');
$sort = $_GET['sort'] ?? 'new';

$where = [];
$params = [];
if ($category) { $where[] = 'p.category_id = ?'; $params[] = $category; }
if ($q !== '') { $where[] = '(p.name LIKE ? OR p.description LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
$sql = "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= match($sort) {
    'price_asc' => ' ORDER BY p.price ASC',
    'price_desc' => ' ORDER BY p.price DESC',
    default => ' ORDER BY p.id DESC'
};
$stmt = $pdo->prepare($sql); $stmt->execute($params); $products = $stmt->fetchAll();
$categories = $pdo->query("SELECT * FROM categories ORDER BY id")->fetchAll();
require 'includes/header.php';
?>
<section class="page-banner"><div class="container"><p class="eyebrow">HƯNG YẾN COLLECTION</p><h1>Tất cả sản phẩm</h1><p>Mix & match theo cách của bạn.</p></div></section>
<section class="container section">
    <form class="toolbar" method="get">
        <input type="text" name="q" value="<?= e($q) ?>" placeholder="Tìm kiếm sản phẩm...">
        <select name="category" onchange="this.form.submit()"><option value="0">Tất cả danh mục</option><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $category==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
        <select name="sort" onchange="this.form.submit()"><option value="new" <?= $sort==='new'?'selected':'' ?>>Mới nhất</option><option value="price_asc" <?= $sort==='price_asc'?'selected':'' ?>>Giá thấp → cao</option><option value="price_desc" <?= $sort==='price_desc'?'selected':'' ?>>Giá cao → thấp</option></select>
        <button class="btn btn-dark" type="submit">Tìm</button>
    </form>
    <div class="product-grid">
    <?php foreach($products as $p): ?>
        <article class="product-card">
            <a href="product.php?id=<?= $p['id'] ?>" class="product-image tone-<?= $p['id'] % 6 ?>"><span class="product-mark">HY</span></a>
            <div class="product-info"><small><?= e($p['category_name']) ?></small><h3><a href="product.php?id=<?= $p['id'] ?>"><?= e($p['name']) ?></a></h3><strong><?= money($p['price']) ?></strong></div>
        </article>
    <?php endforeach; ?>
    </div>
    <?php if (!$products): ?><div class="empty">Không tìm thấy sản phẩm phù hợp.</div><?php endif; ?>
</section>
<?php require 'includes/footer.php'; ?>
