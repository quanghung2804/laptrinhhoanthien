<?php
require_once 'config/config.php';
$page_title = 'Trang chủ';
$pdo = db();
$featured = $pdo->query("SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.is_featured=1 ORDER BY p.id DESC LIMIT 8")->fetchAll();
require 'includes/header.php';
?>
<section class="hero">
    <div class="container hero-inner">
        <div class="hero-copy">
            <p class="eyebrow">NEW SEASON 2026</p>
            <h1>Mặc chất riêng.<br><span>Sống đúng vibe.</span></h1>
            <p>Những item trẻ trung, dễ phối và được chọn lọc cho Gen Z hiện đại.</p>
            <a class="btn btn-dark" href="products.php">Mua sắm ngay →</a>
        </div>
        <div class="hero-art">
            <div class="model-card"><div class="model-silhouette">HƯNG<br>YẾN</div></div>
            <div class="sticker">BE<br>YOUR<br>OWN<br>STYLE</div>
        </div>
    </div>
</section>

<section class="container section">
    <div class="section-head"><div><p class="eyebrow">SHOP BY CATEGORY</p><h2>Chọn phong cách của bạn</h2></div><a href="products.php">Xem tất cả →</a></div>
    <div class="category-grid">
        <a href="products.php?category=1" class="category-card c1"><span>01</span><h3>Áo</h3><small>TEE · SHIRT · HOODIE</small></a>
        <a href="products.php?category=2" class="category-card c2"><span>02</span><h3>Quần</h3><small>JEANS · CARGO · SHORT</small></a>
        <a href="products.php?category=3" class="category-card c3"><span>03</span><h3>Váy</h3><small>SKIRT · DRESS</small></a>
        <a href="products.php?category=4" class="category-card c4"><span>04</span><h3>Phụ kiện</h3><small>BAG · CAP · MORE</small></a>
    </div>
</section>

<section class="section products-section">
    <div class="container">
        <div class="section-head"><div><p class="eyebrow">TRENDING NOW</p><h2>Item đang được yêu thích</h2></div><a href="products.php">Xem thêm →</a></div>
        <div class="product-grid">
        <?php foreach ($featured as $p): ?>
            <article class="product-card">
                <a href="product.php?id=<?= $p['id'] ?>" class="product-image tone-<?= $p['id'] % 6 ?>">
                    <span class="badge">HOT</span><span class="product-mark">HY</span>
                </a>
                <div class="product-info"><small><?= e($p['category_name']) ?></small><h3><a href="product.php?id=<?= $p['id'] ?>"><?= e($p['name']) ?></a></h3><strong><?= money($p['price']) ?></strong></div>
            </article>
        <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="container promo">
    <div><p class="eyebrow">HƯNG YẾN CLUB</p><h2>Style hôm nay,<br>câu chuyện của bạn.</h2><p>Đăng ký thành viên để nhận thông tin bộ sưu tập mới và ưu đãi.</p></div>
    <a class="btn btn-light" href="products.php">Khám phá collection →</a>
</section>
<?php require 'includes/footer.php'; ?>
