</main>
<footer class="footer">
    <div class="container footer-grid">
        <div>
            <div class="logo">HƯNG <span>YẾN</span></div>
            <p>Thời trang trẻ trung, tự tin và đúng chất bạn.</p>
        </div>
        <div><h4>Khám phá</h4><a href="products.php">Tất cả sản phẩm</a><a href="products.php?category=1">Áo</a><a href="products.php?category=2">Quần</a></div>
        <div><h4>Hỗ trợ</h4><a href="cart.php">Giỏ hàng</a><a href="checkout.php">Thanh toán</a><a href="admin/index.php">Quản trị</a></div>
        <div><h4>Liên hệ</h4><p>Hotline: 0909 202 026</p><p>Email: hello@hungyen.local</p><p>Việt Nam</p></div>
    </div>
    <div class="copyright">© 2026 Hưng Yến Fashion. Đồ án môn Lập trình Web.</div>
</footer>
<script src="assets/js/app.js"></script>
</body>
</html>
