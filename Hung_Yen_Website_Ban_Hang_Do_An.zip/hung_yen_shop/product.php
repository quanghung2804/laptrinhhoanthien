<?php
require_once 'config/config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?");
$stmt->execute([$id]); $p = $stmt->fetch();
if (!$p) { http_response_code(404); exit('Không tìm thấy sản phẩm.'); }
$page_title = $p['name'];
require 'includes/header.php';
?>
<section class="container section product-detail">
    <div class="detail-image product-image tone-<?= $p['id'] % 6 ?>"><span class="product-mark">HƯNG<br>YẾN</span></div>
    <div class="detail-content">
        <p class="eyebrow"><?= e($p['category_name']) ?></p>
        <h1><?= e($p['name']) ?></h1>
        <div class="price"><?= money($p['price']) ?></div>
        <p><?= nl2br(e($p['description'])) ?></p>
        <div class="stock">● Còn <?= (int)$p['stock'] ?> sản phẩm</div>
        <form method="post" action="cart.php" class="buy-form">
            <input type="hidden" name="action" value="add"><input type="hidden" name="product_id" value="<?= $p['id'] ?>">
            <label>Số lượng <input type="number" name="qty" value="1" min="1" max="<?= (int)$p['stock'] ?>"></label>
            <button class="btn btn-dark" type="submit">Thêm vào giỏ hàng</button>
        </form>
        <ul class="feature-list"><li>✓ Đổi size trong 7 ngày</li><li>✓ Kiểm tra hàng trước khi nhận</li><li>✓ Đóng gói cẩn thận</li></ul>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
