<?php require_once 'config/config.php'; $page_title='Đặt hàng thành công'; require 'includes/header.php'; ?>
<section class="container section success"><div class="success-icon">✓</div><p class="eyebrow">ORDER RECEIVED</p><h1>Cảm ơn bạn đã đặt hàng!</h1><p>Đơn hàng <strong>#<?=e($_GET['order']??'')?></strong> đã được ghi nhận. Hưng Yến sẽ liên hệ xác nhận sớm.</p><a class="btn btn-dark" href="products.php">Tiếp tục mua sắm</a></section>
<?php require 'includes/footer.php'; ?>
